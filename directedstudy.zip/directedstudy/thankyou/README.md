# AIMS Redesign
A mockup redesign of the Affiliate Identity Management System affiliate request form page for University Systems at the University of Victoria.

####The Site
* `index.html` is the page that gets served.
