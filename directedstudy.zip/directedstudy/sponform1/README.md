# AIMS Redesign
A mockup redesign of the Affiliate Identity Management System affiliate request form page for University Systems at the University of Victoria.

####The Site
* `index.html` is the page that gets served.  We attach our JS to this file.
*  `exmaple.js` is the JS that gets rendered on our page. 
